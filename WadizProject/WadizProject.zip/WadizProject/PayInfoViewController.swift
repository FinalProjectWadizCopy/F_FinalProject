//
//  PayViewController.swift
//  WadizProject
//
//  Created by Pure Yun on 2018. 8. 17..
//  Copyright © 2018년 JhDAT. All rights reserved.
//

import UIKit

class PayInfoViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
}
